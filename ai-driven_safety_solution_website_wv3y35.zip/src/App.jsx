import React from 'react';
    import { Routes, Route } from 'react-router-dom';
    import Navbar from './components/Navbar';
    import Home from './pages/Home';
    import LiveMap from './pages/LiveMap';
    import TrackingHistory from './pages/TrackingHistory';
    import SafetyAlerts from './pages/SafetyAlerts';
    import DevicePairing from './pages/DevicePairing';
    import HelpSupport from './pages/HelpSupport';
    import PrivacySecurity from './pages/PrivacySecurity';

    function App() {
      return (
        <div className="flex flex-col min-h-screen bg-primary text-text-primary">
          <Navbar />
          <main className="flex-grow container mx-auto p-4">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/live-map" element={<LiveMap />} />
              <Route path="/tracking-history" element={<TrackingHistory />} />
              <Route path="/safety-alerts" element={<SafetyAlerts />} />
              <Route path="/device-pairing" element={<DevicePairing />} />
              <Route path="/help-support" element={<HelpSupport />} />
              <Route path="/privacy-security" element={<PrivacySecurity />} />
            </Routes>
          </main>
          <footer className="bg-secondary text-center p-4 mt-auto text-text-secondary text-sm">
            &copy; {new Date().getFullYear()} AI Safety Solution
          </footer>
        </div>
      );
    }

    export default App;
