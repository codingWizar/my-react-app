import React, { useState, useEffect } from 'react';
    import { Link, useLocation } from 'react-router-dom';

    function Navbar() {
      const [isScrolled, setIsScrolled] = useState(false);
      const location = useLocation();

      useEffect(() => {
        const handleScroll = () => {
          if (window.scrollY > 50) {
            setIsScrolled(true);
          } else {
            setIsScrolled(false);
          }
        };

        window.addEventListener('scroll', handleScroll);
        return () => {
          window.removeEventListener('scroll', handleScroll);
        };
      }, []);

      return (
        <nav className={`fixed top-0 left-0 w-full z-10 transition duration-300 ${isScrolled || location.pathname !== "/" ? 'bg-secondary shadow-md' : 'bg-transparent'}`}>
          <div className="container mx-auto flex items-center justify-between p-4">
            <Link to="/" className="text-2xl font-bold text-text-primary hover:text-accent transition duration-200">AI Safety</Link>
            <ul className="flex space-x-6">
              <li><Link to="/" className={`hover:text-accent transition duration-200 ${location.pathname === "/" ? 'text-accent' : ''}`}>Home</Link></li>
              <li><Link to="/live-map" className="hover:text-accent transition duration-200">Live Map</Link></li>
              <li><Link to="/tracking-history" className="hover:text-accent transition duration-200">Tracking History</Link></li>
              <li><Link to="/safety-alerts" className="hover:text-accent transition duration-200">Safety Alerts</Link></li>
              <li><Link to="/device-pairing" className="hover:text-accent transition duration-200">Device Pairing</Link></li>
              <li><Link to="/help-support" className="hover:text-accent transition duration-200">Help & Support</Link></li>
              <li><Link to="/privacy-security" className="hover:text-accent transition duration-200">Privacy & Security</Link></li>
            </ul>
          </div>
        </nav>
      );
    }

    export default Navbar;
