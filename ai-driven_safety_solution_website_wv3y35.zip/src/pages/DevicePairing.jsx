import React from 'react';

    function DevicePairing() {
      return (
        <div>
          <h1 className="text-3xl font-bold mb-4">Device Pairing</h1>
          <p>Connect smartwatches or phones for integrated tracking.</p>
          {/* Add device pairing functionality here */}
        </div>
      );
    }

    export default DevicePairing;
