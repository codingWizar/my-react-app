import React from 'react';

    function TrackingHistory() {
      return (
        <div>
          <h1 className="text-3xl font-bold mb-4">Tracking History</h1>
          <p>View past locations logged every 10 minutes.</p>
          {/* Add location history display here */}
        </div>
      );
    }

    export default TrackingHistory;
