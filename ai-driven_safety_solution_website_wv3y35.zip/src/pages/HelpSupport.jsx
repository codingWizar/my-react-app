import React from 'react';

    function HelpSupport() {
      return (
        <div>
          <h1 className="text-3xl font-bold mb-4">Help & Support</h1>
          <h2 className="text-xl font-semibold mb-2">FAQ</h2>
          {/* Add FAQ content here */}
          <h2 className="text-xl font-semibold mt-4 mb-2">Contact Support</h2>
          {/* Add contact form here */}
        </div>
      );
    }

    export default HelpSupport;
