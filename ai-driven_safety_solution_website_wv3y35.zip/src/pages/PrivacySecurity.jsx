import React from 'react';

    function PrivacySecurity() {
      return (
        <div>
          <h1 className="text-3xl font-bold mb-4">Privacy & Security</h1>
          <p>Information about data protection and user privacy.</p>
          {/* Add privacy and security information here */}
        </div>
      );
    }

    export default PrivacySecurity;
