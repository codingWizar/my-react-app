import React, { useEffect, useRef } from 'react';
    import { Loader } from '@googlemaps/js-api-loader';

    function LiveMap() {
      const mapRef = useRef(null);

      useEffect(() => {
        const loader = new Loader({
          apiKey: 'YOUR_GOOGLE_MAPS_API_KEY', // Replace with your API key
          version: 'weekly',
        });

        loader.load().then(() => {
          const map = new google.maps.Map(mapRef.current, {
            center: { lat: -34.397, lng: 150.644 },
            zoom: 12,
            styles: [
              {
                featureType: "poi",
                stylers: [{ visibility: "off" }],
              },
              {
                featureType: "transit.station",
                stylers: [{ visibility: "off" }],
              },
            ],
          });
          // Add a marker
          new google.maps.Marker({
            position: { lat: -34.397, lng: 150.644 },
            map: map,
            title: "Your Location",
          });
        });
      }, []);

      return (
        <div>
          <h1 className="text-3xl font-bold mb-4">Live Map</h1>
          <div ref={mapRef} style={{ width: '100%', height: '500px', borderRadius: '0.5rem', overflow: 'hidden' }}></div>
          <button className="fixed bottom-4 right-4 bg-danger hover:bg-red-700 text-white font-bold py-2 px-4 rounded-full shadow-md transition duration-200">
            SOS
          </button>
        </div>
      );
    }

    export default LiveMap;
