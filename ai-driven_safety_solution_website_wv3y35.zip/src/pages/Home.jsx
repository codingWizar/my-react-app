import React from 'react';
    import { Link } from 'react-router-dom';

    function Home() {
      return (
        <div>
          {/* Hero Section */}
          <section className="bg-hero-pattern bg-cover bg-center py-20">
            <div className="container mx-auto text-center">
              <h1 className="text-4xl font-bold text-text-primary mb-4">AI-Driven Safety</h1>
              <p className="text-xl text-text-secondary mb-8">Real-time tracking, emergency alerts, and proactive safety at your fingertips.</p>
              <Link to="/safety-alerts" className="bg-danger hover:bg-red-700 text-white font-bold py-3 px-8 rounded-full shadow-md transition duration-200">
                Activate Safety
              </Link>
            </div>
          </section>

          {/* Safety Status Indicator */}
          <section className="py-12">
            <div className="container mx-auto text-center">
              <div className="inline-block rounded-full bg-success text-2xl font-semibold text-white py-4 px-8">
                Safe
              </div>
              <p className="text-lg text-text-secondary mt-4">Your current safety status is based on real-time AI analysis.</p>
            </div>
          </section>

          {/* Quick Access to Features */}
          <section className="py-12 bg-secondary">
            <div className="container mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Live Map */}
              <Link to="/live-map" className="bg-primary rounded-lg shadow-md p-6 hover:shadow-xl transition duration-200">
                <i className="fas fa-map-marked-alt text-4xl text-accent mb-2"></i>
                <h3 className="text-xl font-semibold mb-2">Live Map</h3>
                <p className="text-text-secondary">Track your location in real-time.</p>
              </Link>

              {/* Safety Alerts */}
              <Link to="/safety-alerts" className="bg-primary rounded-lg shadow-md p-6 hover:shadow-xl transition duration-200">
                <i className="fas fa-exclamation-triangle text-4xl text-danger mb-2"></i>
                <h3 className="text-xl font-semibold mb-2">Safety Alerts</h3>
                <p className="text-text-secondary">View and manage emergency alerts.</p>
              </Link>

              {/* Device Pairing */}
              <Link to="/device-pairing" className="bg-primary rounded-lg shadow-md p-6 hover:shadow-xl transition duration-200">
                <i className="fas fa-mobile-alt text-4xl text-accent mb-2"></i>
                <h3 className="text-xl font-semibold mb-2">Device Pairing</h3>
                <p className="text-text-secondary">Connect your devices for integrated tracking.</p>
              </Link>

              {/* Tracking History */}
              <Link to="/tracking-history" className="bg-primary rounded-lg shadow-md p-6 hover:shadow-xl transition duration-200">
                <i className="fas fa-history text-4xl text-accent mb-2"></i>
                <h3 className="text-xl font-semibold mb-2">Tracking History</h3>
                <p className="text-text-secondary">View your past locations.</p>
              </Link>

              {/* Help & Support */}
              <Link to="/help-support" className="bg-primary rounded-lg shadow-md p-6 hover:shadow-xl transition duration-200">
                <i className="fas fa-question-circle text-4xl text-accent mb-2"></i>
                <h3 className="text-xl font-semibold mb-2">Help & Support</h3>
                <p className="text-text-secondary">Get help and find answers.</p>
              </Link>

              {/* Privacy & Security */}
              <Link to="/privacy-security" className="bg-primary rounded-lg shadow-md p-6 hover:shadow-xl transition duration-200">
                <i className="fas fa-shield-alt text-4xl text-accent mb-2"></i>
                <h3 className="text-xl font-semibold mb-2">Privacy & Security</h3>
                <p className="text-text-secondary">Learn about our privacy policies.</p>
              </Link>
            </div>
          </section>
        </div>
      );
    }

    export default Home;
