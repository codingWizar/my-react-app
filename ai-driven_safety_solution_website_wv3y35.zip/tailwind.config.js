/** @type {import('tailwindcss').Config} */
    export default {
      content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
      ],
      theme: {
        extend: {
          colors: {
            'primary': '#1a202c', // Dark background
            'secondary': '#2d3748', // Slightly lighter background
            'accent': '#63b3ed', // Blue accent
            'danger': '#e53e3e', // Red for alerts
            'success': '#48bb78', // Green for safe status
            'text-primary': '#f7fafc', // Light text
            'text-secondary': '#a0aec0', // Gray text
          },
          fontFamily: {
            sans: ['Roboto', 'sans-serif'],
            serif: ['Merriweather', 'serif'],
          },
          boxShadow: {
            'md': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
          },
          borderRadius: {
            'md': '0.375rem',
            'full': '9999px',
          },
          backgroundImage: {
            'hero-pattern': "url('/src/assets/hero-background.jpg')", // Placeholder, replace with actual image path
          }
        },
      },
      plugins: [],
    }
